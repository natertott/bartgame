BARTGAME original standalone GBA game.
Source: 51880a55e6ecf86728f3a0923e5547e7bdeed5a0
ROM SHA256: 0dd8554384b53e618140f8c61590fc7e6a7ff0888f296ece034a95f357b34fdd
See the adjacent README.md and regional-handoff-review/README.md for controls, the feature audit and actual mGBA captures.
