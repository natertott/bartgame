import json,hashlib,shutil
from pathlib import Path
ROOT=Path('/workspace/setup/regional-integration')
QUEST=Path('/workspace/setup/regional-journey')
source=(ROOT/'candidate4/source-commit.txt').read_text().strip()
rom_hash=hashlib.sha256((ROOT/'candidate4/bartgame.gba').read_bytes()).hexdigest()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def public_copy(src,dst):
    for p in Path(src).rglob('*'):
        rel=p.relative_to(src)
        if not p.is_file() or any(v in ('private','bundle') for v in rel.parts):continue
        if p.suffix.lower() not in ('.json','.png','.gif','.wav','.txt','.py'):continue
        d=Path(dst)/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
summary=json.loads((QUEST/'candidate4-summary.json').read_text())
aggregate=ROOT/'quests-c4-aggregate';aggregate.mkdir(exist_ok=True)
checks=[];cases=[]
for case in summary['cases']:
    if not case['case'].startswith('c4-q'):continue
    original=Path(case['report']);r=json.loads(original.read_text());name=case['case'][3:]
    assert r['rom_sha256']==rom_hash and r['source_commit']==source and all(c['passed'] for c in r['checks']) and r['scope_complete'] and not r['errors']
    public_copy(original.parent,aggregate/name)
    cases.append(dict(case=name,report=name+'/report.json',report_sha256=sha(original),passed=sum(c['passed'] for c in r['checks']),total=len(r['checks'])))
    for c in r['checks']:checks.append(dict(c, name=name+': '+c['name']))
assert len(cases)==13 and len(checks)==90
(aggregate/'report.json').write_text(json.dumps(dict(source_commit=source,rom_sha256=rom_hash,method='Mechanical aggregation of thirteen unchanged actual mGBA quest/origin reports; each child report retains inputs, fixtures, native media and provenance.',scope=summary['scope'],limits=summary['limits'],cases=cases,checks=checks,passed=sum(bool(c['passed']) for c in checks),total=len(checks),complete=True,errors=[]),indent=2)+'\n')
native={
 'opening':ROOT/'c4-opening','hub':ROOT/'c4-hub','access':ROOT/'c4-access','resources':ROOT/'c4-resources','arrivals':ROOT/'c4-arrivals2',
 'quests':aggregate,'chain':QUEST/'c4-chain','chain-guard':QUEST/'c4-guard','quest-stakes':QUEST/'c4-stakes',
 'maps':ROOT/'maps-candidate4','maps-pending':ROOT/'maps-pending-candidate4','maps-cold-cream':ROOT/'maps-cold-cream-candidate4',
 'saves':ROOT/'save-native-candidate4','saves-original':ROOT/'save-native-candidate4-original',
 'mechanisms':ROOT/'mechanisms-live-c4/main','mechanisms-fields':ROOT/'mechanisms-live-c4/fields','mechanisms-lily':ROOT/'mechanisms-live-c4/lily','mechanisms-lava':ROOT/'mechanisms-live-c4/lava','mechanisms-cream':ROOT/'mechanisms-live-c4/cream',
 'performance':ROOT/'performance-c4','boundaries':ROOT/'boundaries-c4','mitigation':ROOT/'mitigation-c4',
 'preservation-music':ROOT/'preservation-music-c4','preservation-victory':ROOT/'preservation-victory-c4','preservation-drain':ROOT/'preservation-drain-c4','preservation-cream':ROOT/'preservation-cream-retirement-c4','preservation-drop3':ROOT/'preservation-cream-drop5-c4','preservation-drop4':ROOT/'preservation-cream-drop1432-c4',
}
for name in ('fusions','memory','portal','wave'):native['pairs-'+name]=ROOT/('pairs-c4-final-'+name)
host={
 'placement':ROOT/'c4-placement/report.json','reach':ROOT/'c4-reach/report.json','art':ROOT/'c4-art.json',
 'host-events':ROOT/'events-c4-host.json','host-budget':ROOT/'legacy-spawn-budget-c4-host.json','host-saves':ROOT/'save-host-candidate4/report.json',
 'host-mechanisms':ROOT/'host-mechanisms-c4/report.json',
 'host-objects':ROOT/'host-objects-c4/report.json','host-mobility':ROOT/'host-mobility-c4/report.json',
}
config=dict(native={n:str(p) for n,p in native.items()},host={n:str(p) for n,p in host.items()},other={'build.log':'/workspace/setup/regional-integration-build5.log'})
(ROOT/'release-evidence.json').write_text(json.dumps(config,indent=2)+'\n')
print('native',len(native),'host',len(host),'questchecks',len(checks))
for n,p in {**native,**host}.items():
    f=p/'report.json' if n in native else p
    if not f.exists():print('PENDING',n,str(f))
