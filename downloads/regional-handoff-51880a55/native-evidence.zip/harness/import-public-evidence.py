import json,hashlib,shutil
from pathlib import Path
base=Path('/workspace/setup/regional-integration')
repo=Path('/workspace/bartgame');dest=repo/'regional-handoff-review/validation'
config=json.loads((base/'release-evidence.json').read_text())
source=(base/'candidate4/source-commit.txt').read_text().strip()
romhash=hashlib.sha256((base/'candidate4/bartgame.gba').read_bytes()).hexdigest()
receipts=[]
for name,folder in config['native'].items():
    folder=Path(folder);data=json.loads((folder/'report.json').read_text())
    assert romhash in (data.get('rom_sha256'),data.get('sha256')),name
    assert data.get('source_commit',source)==source,name
    for k in ('complete','scope_complete','completed'):assert data.get(k) is not False,(name,k)
    assert not data.get('errors') and not data.get('error'),name
    for c in data.get('checks',[]):
        for k in ('passed','pass','ok'):assert c.get(k) is not False,(name,c)
    if isinstance(data.get('passed'),bool):assert data['passed'],name
    elif 'passed' in data and 'total' in data:assert data['passed']==data['total'],name
    target=dest/name;target.mkdir(parents=True,exist_ok=True)
    count=0
    for p in folder.rglob('*'):
        rel=p.relative_to(folder)
        if not p.is_file() or any(v in ('private','bundle') for v in rel.parts):continue
        if p.suffix.lower() not in ('.json','.png','.gif','.txt','.py'):continue
        d=target/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);count+=1
    receipts.append(dict(alias=name,source=str(folder),report_sha256=hashlib.sha256((folder/'report.json').read_bytes()).hexdigest(),copied_files=count,kind='actual mGBA input/output, scoped in each report'))
for name,filename in config['host'].items():
    filename=Path(filename);data=json.loads(filename.read_text());assert not data.get('failed') and data.get('passed') is not False,name
    folder=dest/name;folder.mkdir(parents=True,exist_ok=True);shutil.copy2(filename,folder/'report.json')
    receipts.append(dict(alias=name,source=str(filename),report_sha256=hashlib.sha256(filename.read_bytes()).hexdigest(),kind='host execution or native asset decode; not mGBA playthrough'))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,rom_sha256=romhash,records=receipts,note='Full native archive also contains audio and frozen build. No private SRAM/emulator-state files published.'),indent=2)+'\n')
print('imported',len(receipts),'suites',sum(r.get('copied_files',1) for r in receipts),'public files')
