#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <stdlib.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef u8 bool8;
#define TRUE 1
#define FALSE 0

enum { PS_NORMAL, PS_ROLL, PS_ATTACK, PS_HURT, PS_FALL, PS_JUMP, PS_ITEMGET, PS_DEAD, PS_TALK, PS_FROZEN, PS_LIFT, PS_CARRY, PS_SWALLOWED };
enum { EQ_NONE, EQ_SWORD, EQ_BOMBS, EQ_LAMP, EQ_CLOAK, EQ_SHIELD, EQ_BOW, EQ_HUBCAP, EQ_COUNT };
enum { SLOT_A, SLOT_B, SLOT_L, SLOT_COUNT };
enum { CARRY_NONE, CARRY_BUSH, CARRY_ROCK, CARRY_BOULDER, CARRY_POT };
typedef struct {
    s16 hp, hp_max;
    u16 gilt;
    u8 keys, bombs, items;
    u8 equip[SLOT_COUNT]; /* EQ_* per button: A, B, L */
    u8 sword_dmg;
    s16 safe_x, safe_y; /* last safe standing spot, room px */
    u8 safe_timer;
    u8 push_timer;      /* frames pushing into a ledge */
    u8 attack_timer;
    u8 sword_active;    /* sword hitbox live */
    u8 sword_phase;
    u8 lamp_timer;      /* lamp swing live */
    u8 dead_timer;
    u8 item_cooldown;
    u8 got_item;        /* item shown over the head during ITEMGET */
    u16 got_timer;
    u8 hearts_pieces;
    u8 input_lock;
    u8 queued_attack;
    u8 carry;           /* CARRY_* over the head */
    u8 shield_up;       /* the shield held before the hero this frame */
    u8 arrows;          /* for the bow, 50 at most */
    u8 items2;          /* ITEM2_* */
} PlayerState;
#define ITEM_SWORD 0x01
#define ITEM_BOMBS 0x02
#define ITEM_LAMP 0x04
#define ITEM_CLOAK 0x08
#define ITEM_RELIC 0x10
#define ITEM_GAUNTLET 0x20 /* worn: lifts boulders */
#define ITEM_SHIELD 0x40   /* the Bark Shield */
#define ITEM2_BOW 0x01     /* the Thorn Bow, with its arrows */
#define ITEM2_HUBCAP 0x02  /* the Drain Cap: the way home */
#define ITEM2_MAP 0x04     /* the Map: every cell of the wood drawn */
#define ITEM2_ASTROLABE 0x08 /* the Astrolabe: chests, the Heart and the barriers marked */
#define ITEM2_SHIELD_UPGRADE 0x10 /* green-and-gold visual shield variant */
enum { EN_BEETLE, EN_BAT, EN_SPITTER, EN_SLIME, EN_KNIGHT, EN_BOSS,
    EN_GILT_LEECH, EN_ROOT_MAW, EN_RELIQUARY_SNOUT, EN_COUNT };
#define EN_PROTO_ROPE EN_GILT_LEECH
#define EN_PROTO_LEEVER EN_ROOT_MAW
#define EN_PROTO_HELMASAUR EN_RELIQUARY_SNOUT
#define APPEARANCE_SRAM_OFFSET 0x7F00u /* reserved final256 bytes of32KB SRAM */
#define SHEET_HERO 0
#define F_HERO_IDLE_S 0
#define F_HERO_WALK_S1 1
#define F_HERO_WALK_S2 2
#define F_HERO_IDLE_N 3
#define F_HERO_WALK_N1 4
#define F_HERO_WALK_N2 5
#define F_HERO_IDLE_E 6
#define F_HERO_WALK_E1 7
#define F_HERO_WALK_E2 8
#define F_HERO_ATK_S 9
#define F_HERO_ATK_N 10
#define F_HERO_ATK_E 11
#define F_HERO_ATK_S1 12
#define F_HERO_ATK_N1 13
#define F_HERO_ATK_E1 14
#define F_HERO_ATK_S3 15
#define F_HERO_ATK_N3 16
#define F_HERO_ATK_E3 17
#define F_HERO_ROLL_1 18
#define F_HERO_ROLL_2 19
#define F_HERO_ROLL_3 20
#define F_HERO_ROLL_4 21
#define F_HERO_ROLL_5 22
#define F_HERO_ROLL_6 23
#define F_HERO_ROLL_7 24
#define F_HERO_HURT_S 25
#define F_HERO_HURT_N 26
#define F_HERO_HURT_E 27
#define F_HERO_JUMP_S 28
#define F_HERO_JUMP_N 29
#define F_HERO_JUMP_E 30
#define F_HERO_ITEMGET 31
#define F_HERO_CARRY_S 32
#define F_HERO_CARRY_S1 33
#define F_HERO_CARRY_S2 34
#define F_HERO_CARRY_N 35
#define F_HERO_CARRY_N1 36
#define F_HERO_CARRY_N2 37
#define F_HERO_CARRY_E 38
#define F_HERO_CARRY_E1 39
#define F_HERO_CARRY_E2 40
#define F_HERO_DROWN_1 41
#define F_HERO_DROWN_2 42
#define F_HERO_DROWN_3 43
#define F_HERO_FALL_1 44
#define F_HERO_FALL_2 45
#define F_HERO_FALL_3 46
#define F_HERO_GUARD_S 47
#define F_HERO_GUARD_N 48
#define F_HERO_GUARD_E 49
#define F_HERO_USE_N1 50
#define F_HERO_CAPE_N1 51
#define F_HERO_USE_N2 52
#define F_HERO_CAPE_N2 53
#define F_HERO_USE_N3 54
#define F_HERO_CAPE_N3 55
#define F_HERO_USE_E1 56
#define F_HERO_CAPE_E1 57
#define F_HERO_USE_E2 58
#define F_HERO_CAPE_E2 59
#define F_HERO_USE_E3 60
#define F_HERO_CAPE_E3 61
#define F_HERO_USE_S1 62
#define F_HERO_CAPE_S1 63
#define F_HERO_USE_S2 64
#define F_HERO_CAPE_S2 65
#define F_HERO_USE_S3 66
#define F_HERO_CAPE_S3 67
#define F_HERO_GUARD_N1 68
#define F_HERO_GUARD_N2 69
#define F_HERO_GUARD_E1 70
#define F_HERO_GUARD_E2 71
#define F_HERO_GUARD_S1 72
#define F_HERO_GUARD_S2 73
#define F_HERO_LIFT_N0 74
#define F_HERO_LIFT_N1 75
#define F_HERO_LIFT_N2 76
#define F_HERO_LIFT_E0 77
#define F_HERO_LIFT_E1 78
#define F_HERO_LIFT_E2 79
#define F_HERO_LIFT_S0 80
#define F_HERO_LIFT_S1 81
#define F_HERO_LIFT_S2 82
#define F_HERO_DEAD_0 83
#define F_HERO_DEAD_1 84
#define F_HERO_DEAD_2 85
#define F_HERO_BOW_N0 86
#define F_HERO_BOW_N1 87
#define F_HERO_BOW_N2 88
#define F_HERO_BOW_E0 89
#define F_HERO_BOW_E1 90
#define F_HERO_BOW_E2 91
#define F_HERO_BOW_S0 92
#define F_HERO_BOW_S1 93
#define F_HERO_BOW_S2 94
#define F_HERO_ROLL_N1 95
#define F_HERO_ROLL_N6 96
#define F_HERO_ROLL_N7 97
#define F_HERO_ROLL_S1 98
#define F_HERO_ROLL_S6 99
#define F_HERO_ROLL_S7 100
#define SHEET_SWORD 1
#define F_SWORD_BLADE_S 0
#define F_SWORD_BLADE_E 1
#define F_SWORD_BLADE_SE 2
#define SHEET_SHIELD 2
#define F_SHIELD_FRONT 0
#define F_SHIELD_SIDE 1
#define F_SHIELD_BACK 2
#define F_SHIELD_UPGRADED_FRONT 3
#define F_SHIELD_UPGRADED_SIDE 4
#define F_SHIELD_UPGRADED_BACK 5
#define SHEET_ITEMS 3
#define F_ITEMS_NONE 0
#define F_ITEMS_BOMBS 1
#define F_ITEMS_LAMP 2
#define F_ITEMS_CLOAK 3
#define F_ITEMS_KEY 4
#define F_ITEMS_HEART_PIECE 5
#define F_ITEMS_HEART_CONTAINER 6
#define F_ITEMS_GILT_BIG 7
#define F_ITEMS_RELIC 8
#define F_ITEMS_HEART 9
#define F_ITEMS_GILT 10
#define F_ITEMS_BOMB_PICKUP 11
#define F_ITEMS_SPARK 12
#define F_ITEMS_GRAIL 13
#define F_ITEMS_GAUNTLET 14
#define F_ITEMS_BOW 15
#define F_ITEMS_ARROW1 16
#define F_ITEMS_ARROW5 17
#define F_ITEMS_ARROW10 18
#define F_ITEMS_HUBCAP 19
#define F_ITEMS_BOMB_LIT 20
#define SHEET_BEETLE 4
#define F_BEETLE_WALK_S1 0
#define F_BEETLE_WALK_S2 1
#define F_BEETLE_WALK_E1 2
#define F_BEETLE_WALK_E2 3
#define SHEET_BAT 5
#define F_BAT_FLY1 0
#define F_BAT_FLY2 1
#define F_BAT_REST 2
#define SHEET_SLIME 6
#define F_SLIME_IDLE 0
#define F_SLIME_SQUASH 1
#define F_SLIME_JUMP 2
#define SHEET_SPITTER 7
#define F_SPITTER_IDLE_S 0
#define F_SPITTER_WALK_S 1
#define F_SPITTER_SPIT_S 2
#define F_SPITTER_IDLE_N 3
#define F_SPITTER_WALK_N 4
#define F_SPITTER_SPIT_N 5
#define F_SPITTER_IDLE_E 6
#define F_SPITTER_WALK_E 7
#define F_SPITTER_SPIT_E 8
#define SHEET_KNIGHT 8
#define F_KNIGHT_WALK_S1 0
#define F_KNIGHT_WALK_S2 1
#define F_KNIGHT_IDLE_S 2
#define F_KNIGHT_ATK_S 3
#define F_KNIGHT_WALK_N1 4
#define F_KNIGHT_WALK_N2 5
#define F_KNIGHT_IDLE_N 6
#define F_KNIGHT_ATK_N 7
#define F_KNIGHT_WALK_E1 8
#define F_KNIGHT_WALK_E2 9
#define F_KNIGHT_IDLE_E 10
#define F_KNIGHT_ATK_E 11
#define SHEET_KSWORD 9
#define F_KSWORD_BLADE_E 0
#define F_KSWORD_BLADE_S 1
#define SHEET_FX 10
#define F_FX_PUFF1 0
#define F_FX_PUFF2 1
#define F_FX_PUFF3 2
#define F_FX_CLANG 3
#define F_FX_BLAST1 4
#define F_FX_BLAST2 5
#define F_FX_BLAST3 6
#define F_FX_FLAME1 7
#define F_FX_FLAME2 8
#define F_FX_BOMB1 9
#define F_FX_BOMB2 10
#define F_FX_FIREFLY1 11
#define F_FX_FIREFLY2 12
#define SHEET_PROJ 11
#define F_PROJ_SEED 0
#define F_PROJ_SPORE 1
#define F_PROJ_SHARD 2
#define SHEET_NPC 12
#define F_NPC_SAGE 0
#define F_NPC_MERCHANT 1
#define F_NPC_HERMIT 2
#define F_NPC_NUN 3
#define F_NPC_GARDENER 4
#define F_NPC_SISTER_MARY_GRACE 5
#define F_NPC_BROTHER_MARK 6
#define SHEET_BOSS 13
#define F_BOSS_PULSE1 0
#define F_BOSS_PULSE2 1
#define F_BOSS_HURT 2
#define SHEET_LIFT 14
#define F_LIFT_BUSH 0
#define F_LIFT_ROCK 1
#define F_LIFT_BOULDER 2
#define F_LIFT_POT 3
#define SHEET_ARROW 15
#define F_ARROW_E 0
#define F_ARROW_S 1
#define F_ARROW_N 2
#define SHEET_MOUTH 16
#define F_MOUTH_M1 0
#define F_MOUTH_M2 1
#define F_MOUTH_M3 2
#define SHEET_MARKS 17
#define F_MARKS_HERE 0
#define F_MARKS_DOOR 1
#define F_MARKS_FOLK 2
#define F_MARKS_QUEST 3
#define F_MARKS_RELIC 4
#define F_MARKS_CHEST 5
#define F_MARKS_HEART 6
#define F_MARKS_BOSS 7
#define F_MARKS_CRACK 8
#define F_MARKS_WEB 9
#define F_MARKS_LOCK 10
#define F_MARKS_CHASM 11
#define F_MARKS_THORN 12
#define SHEET_DOTS 18
#define F_DOTS_HERE 0
#define F_DOTS_DOOR 1
#define F_DOTS_FOLK 2
#define F_DOTS_QUEST 3
#define F_DOTS_RELIC 4
#define F_DOTS_CHEST 5
#define F_DOTS_BOSS 6
#define F_DOTS_CRACK 7
#define F_DOTS_WEB 8
#define F_DOTS_LOCK 9
#define F_DOTS_CHASM 10
#define F_DOTS_THORN 11
#define SHEET_CURSOR 19
#define F_CURSOR_CELL 0
#define SHEET_PICK32 20
#define F_PICK32_HEART 0
#define F_PICK32_GILT 1
#define F_PICK32_BOMB_PICKUP 2
#define F_PICK32_GILT_BIG 3
#define F_PICK32_KEY 4
#define F_PICK32_RELIC 5
#define F_PICK32_GRAIL 6
#define F_PICK32_ARROW1 7
#define F_PICK32_ARROW5 8
#define F_PICK32_ARROW10 9
#define SHEET_ICON32 21
#define F_ICON32_NONE 0
#define F_ICON32_BOMBS 1
#define F_ICON32_LAMP 2
#define F_ICON32_CLOAK 3
#define F_ICON32_KEY 4
#define F_ICON32_HEART_PIECE 5
#define F_ICON32_HEART_CONTAINER 6
#define F_ICON32_GILT_BIG 7
#define F_ICON32_RELIC 8
#define F_ICON32_GAUNTLET 9
#define F_ICON32_BOW 10
#define F_ICON32_HUBCAP 11
#define F_ICON32_MAP 12
#define F_ICON32_ASTROLABE 13
#define F_ICON32_SWORD 14
#define F_ICON32_SHIELD 15
#define F_ICON32_SHIELD_UPGRADED 16
#define SHEET_UIMARKS 22
#define F_UIMARKS_NEXT 0
#define F_UIMARKS_PICK 1
#define F_UIMARKS_CORNER 2
#define F_UIMARKS_BADGE_A 3
#define F_UIMARKS_BADGE_B 4
#define F_UIMARKS_BADGE_L 5
#define SHEET_FACE 23
#define F_FACE_BLOOM_SURPRISED 0
#define F_FACE_PEDDLER 1
#define F_FACE_GATEKEEPER 2
#define F_FACE_HERMIT 3
#define F_FACE_NUN 4
#define F_FACE_GARDENER 5
#define SHEET_PEDDLER_HEAD 24
#define F_PEDDLER_HEAD_OPEN 0
#define F_PEDDLER_HEAD_BLINK 1
#define F_PEDDLER_HEAD_LEFT 2
#define F_PEDDLER_HEAD_DOWN 3
#define F_PEDDLER_HEAD_GRIN 4
#define SHEET_PEDDLER_BODY 25
#define F_PEDDLER_BODY_REST 0
#define F_PEDDLER_BODY_TAP 1
#define F_PEDDLER_BODY_TAP2 2
#define F_PEDDLER_BODY_LIFT 3
#define F_PEDDLER_BODY_SPIN9 4
#define F_PEDDLER_BODY_SPIN7 5
#define F_PEDDLER_BODY_SPIN5 6
#define F_PEDDLER_BODY_SPIN3 7
#define F_PEDDLER_BODY_SPIN5B 8
#define F_PEDDLER_BODY_SPIN7B 9
#define F_PEDDLER_BODY_SPIN9B 10
#define F_PEDDLER_BODY_SLAP 11
#define F_PEDDLER_BODY_RUB0 12
#define F_PEDDLER_BODY_RUB1 13
#define SHEET_GATEKEEPER 26
#define F_GATEKEEPER_IDLE 0
#define F_GATEKEEPER_BLINK 1
#define F_GATEKEEPER_BREATH 2
#define F_GATEKEEPER_BREATH_BLINK 3
#define F_GATEKEEPER_KINDLE 4
#define F_GATEKEEPER_KINDLE_BLINK 5
#define SHEET_WISP 27
#define F_WISP_W0 0
#define F_WISP_W1 1
#define F_WISP_W2 2
#define F_WISP_W3 3
#define SHEET_BLOOMFX 28
#define F_BLOOMFX_SWORD_N0 0
#define F_BLOOMFX_SWORD_N1 1
#define F_BLOOMFX_SWORD_N2 2
#define F_BLOOMFX_SWORD_N3 3
#define F_BLOOMFX_SWORD_N4 4
#define F_BLOOMFX_SWORD_E0 5
#define F_BLOOMFX_SWORD_E1 6
#define F_BLOOMFX_SWORD_E2 7
#define F_BLOOMFX_SWORD_E3 8
#define F_BLOOMFX_SWORD_E4 9
#define F_BLOOMFX_SWORD_S0 10
#define F_BLOOMFX_SWORD_S1 11
#define F_BLOOMFX_SWORD_S2 12
#define F_BLOOMFX_SWORD_S3 13
#define F_BLOOMFX_SWORD_S4 14
#define F_BLOOMFX_SWORD_W0 15
#define F_BLOOMFX_SWORD_W1 16
#define F_BLOOMFX_SWORD_W2 17
#define F_BLOOMFX_SWORD_W3 18
#define F_BLOOMFX_SWORD_W4 19
#define F_BLOOMFX_BOW_N0 20
#define F_BLOOMFX_BOW_N1 21
#define F_BLOOMFX_BOW_N2 22
#define F_BLOOMFX_BOW_E0 23
#define F_BLOOMFX_BOW_E1 24
#define F_BLOOMFX_BOW_E2 25
#define F_BLOOMFX_BOW_S0 26
#define F_BLOOMFX_BOW_S1 27
#define F_BLOOMFX_BOW_S2 28
#define F_BLOOMFX_LAMP_N0 29
#define F_BLOOMFX_LAMP_N1 30
#define F_BLOOMFX_LAMP_N2 31
#define F_BLOOMFX_LAMP_E0 32
#define F_BLOOMFX_LAMP_E1 33
#define F_BLOOMFX_LAMP_E2 34
#define F_BLOOMFX_LAMP_S0 35
#define F_BLOOMFX_LAMP_S1 36
#define F_BLOOMFX_LAMP_S2 37
#define F_BLOOMFX_CAPE_N0 38
#define F_BLOOMFX_CAPE_N1 39
#define F_BLOOMFX_CAPE_N2 40
#define F_BLOOMFX_CAPE_E0 41
#define F_BLOOMFX_CAPE_E1 42
#define F_BLOOMFX_CAPE_E2 43
#define F_BLOOMFX_CAPE_S0 44
#define F_BLOOMFX_CAPE_S1 45
#define F_BLOOMFX_CAPE_S2 46
#define SHEET_BLOOMSHADOW 29
#define F_BLOOMSHADOW_SHADOW 0
#define SHEET_INTERACTIVECHEST 30
#define F_INTERACTIVECHEST_WOODEN_CLOSED 0
#define F_INTERACTIVECHEST_WOODEN_OPEN 1
#define F_INTERACTIVECHEST_BRASS_CLOSED 2
#define F_INTERACTIVECHEST_BRASS_OPEN 3
#define F_INTERACTIVECHEST_RELIC_CLOSED 4
#define F_INTERACTIVECHEST_RELIC_OPEN 5
#define SHEET_INTERACTIVEENTRY 31
#define F_INTERACTIVEENTRY_CAVE 0
#define F_INTERACTIVEENTRY_HOLLOW 1
#define F_INTERACTIVEENTRY_THICKET 2
#define F_INTERACTIVEENTRY_CAVE_CLOSED 3
#define F_INTERACTIVEENTRY_HOLLOW_CLOSED 4
#define F_INTERACTIVEENTRY_THICKET_CLOSED 5
#define PAL_OBJ_HERO 0
#define PAL_OBJ_FX 1
#define PAL_OBJ_BUGS 2
#define PAL_OBJ_BLIGHT 3
#define PAL_OBJ_IRON 4
#define PAL_OBJ_FOLK 5
#define PAL_OBJ_PORTRAIT 6
#define PAL_OBJ_LIFT 7
#define PAL_OBJ_UI 8
#define PAL_OBJ_GEAR 9
#define PAL_OBJ_ITEMS 10
#define PAL_OBJ_PICK 11
#define PAL_OBJ_ICONS 12
#define PAL_OBJ_PEDDLER 13
#define PAL_OBJ_GATEKEEPER 14
#define PAL_OBJ_UIKIT 15
#define SHEET_PROTO_ROPE 100
#define F_PROTO_ROPE_IDLE_N 0
#define F_PROTO_ROPE_IDLE_E 1
#define F_PROTO_ROPE_IDLE_S 2
#define F_PROTO_ROPE_IDLE_W 3
#define F_PROTO_ROPE_WALK1_N 4
#define F_PROTO_ROPE_WALK1_E 5
#define F_PROTO_ROPE_WALK1_S 6
#define F_PROTO_ROPE_WALK1_W 7
#define F_PROTO_ROPE_WALK2_N 8
#define F_PROTO_ROPE_WALK2_E 9
#define F_PROTO_ROPE_WALK2_S 10
#define F_PROTO_ROPE_WALK2_W 11
#define F_PROTO_ROPE_TELL_N 12
#define F_PROTO_ROPE_TELL_E 13
#define F_PROTO_ROPE_TELL_S 14
#define F_PROTO_ROPE_TELL_W 15
#define F_PROTO_ROPE_ATTACK_N 16
#define F_PROTO_ROPE_ATTACK_E 17
#define F_PROTO_ROPE_ATTACK_S 18
#define F_PROTO_ROPE_ATTACK_W 19
#define F_PROTO_ROPE_RECOVER_N 20
#define F_PROTO_ROPE_RECOVER_E 21
#define F_PROTO_ROPE_RECOVER_S 22
#define F_PROTO_ROPE_RECOVER_W 23
#define F_PROTO_ROPE_HURT_N 24
#define F_PROTO_ROPE_HURT_E 25
#define F_PROTO_ROPE_HURT_S 26
#define F_PROTO_ROPE_HURT_W 27
#define F_PROTO_ROPE_BURIED_N 28
#define F_PROTO_ROPE_BURIED_E 29
#define F_PROTO_ROPE_BURIED_S 30
#define F_PROTO_ROPE_BURIED_W 31
#define SHEET_PROTO_LEEVER 101
#define F_PROTO_LEEVER_IDLE_N 0
#define F_PROTO_LEEVER_IDLE_E 1
#define F_PROTO_LEEVER_IDLE_S 2
#define F_PROTO_LEEVER_IDLE_W 3
#define F_PROTO_LEEVER_WALK1_N 4
#define F_PROTO_LEEVER_WALK1_E 5
#define F_PROTO_LEEVER_WALK1_S 6
#define F_PROTO_LEEVER_WALK1_W 7
#define F_PROTO_LEEVER_WALK2_N 8
#define F_PROTO_LEEVER_WALK2_E 9
#define F_PROTO_LEEVER_WALK2_S 10
#define F_PROTO_LEEVER_WALK2_W 11
#define F_PROTO_LEEVER_TELL_N 12
#define F_PROTO_LEEVER_TELL_E 13
#define F_PROTO_LEEVER_TELL_S 14
#define F_PROTO_LEEVER_TELL_W 15
#define F_PROTO_LEEVER_ATTACK_N 16
#define F_PROTO_LEEVER_ATTACK_E 17
#define F_PROTO_LEEVER_ATTACK_S 18
#define F_PROTO_LEEVER_ATTACK_W 19
#define F_PROTO_LEEVER_RECOVER_N 20
#define F_PROTO_LEEVER_RECOVER_E 21
#define F_PROTO_LEEVER_RECOVER_S 22
#define F_PROTO_LEEVER_RECOVER_W 23
#define F_PROTO_LEEVER_HURT_N 24
#define F_PROTO_LEEVER_HURT_E 25
#define F_PROTO_LEEVER_HURT_S 26
#define F_PROTO_LEEVER_HURT_W 27
#define F_PROTO_LEEVER_BURIED_N 28
#define F_PROTO_LEEVER_BURIED_E 29
#define F_PROTO_LEEVER_BURIED_S 30
#define F_PROTO_LEEVER_BURIED_W 31
#define SHEET_PROTO_HELMASAUR 102
#define F_PROTO_HELMASAUR_IDLE_N 0
#define F_PROTO_HELMASAUR_IDLE_E 1
#define F_PROTO_HELMASAUR_IDLE_S 2
#define F_PROTO_HELMASAUR_IDLE_W 3
#define F_PROTO_HELMASAUR_WALK1_N 4
#define F_PROTO_HELMASAUR_WALK1_E 5
#define F_PROTO_HELMASAUR_WALK1_S 6
#define F_PROTO_HELMASAUR_WALK1_W 7
#define F_PROTO_HELMASAUR_WALK2_N 8
#define F_PROTO_HELMASAUR_WALK2_E 9
#define F_PROTO_HELMASAUR_WALK2_S 10
#define F_PROTO_HELMASAUR_WALK2_W 11
#define F_PROTO_HELMASAUR_TELL_N 12
#define F_PROTO_HELMASAUR_TELL_E 13
#define F_PROTO_HELMASAUR_TELL_S 14
#define F_PROTO_HELMASAUR_TELL_W 15
#define F_PROTO_HELMASAUR_ATTACK_N 16
#define F_PROTO_HELMASAUR_ATTACK_E 17
#define F_PROTO_HELMASAUR_ATTACK_S 18
#define F_PROTO_HELMASAUR_ATTACK_W 19
#define F_PROTO_HELMASAUR_RECOVER_N 20
#define F_PROTO_HELMASAUR_RECOVER_E 21
#define F_PROTO_HELMASAUR_RECOVER_S 22
#define F_PROTO_HELMASAUR_RECOVER_W 23
#define F_PROTO_HELMASAUR_HURT_N 24
#define F_PROTO_HELMASAUR_HURT_E 25
#define F_PROTO_HELMASAUR_HURT_S 26
#define F_PROTO_HELMASAUR_HURT_W 27
#define F_PROTO_HELMASAUR_BURIED_N 28
#define F_PROTO_HELMASAUR_BURIED_E 29
#define F_PROTO_HELMASAUR_BURIED_S 30
#define F_PROTO_HELMASAUR_BURIED_W 31
#ifndef JOURNAL_H
#define JOURNAL_H


/* The arcade remembers discoveries independently of a run. IDs are saved;
   append new entries rather than renumbering existing ones. */
enum {
    JI_SWORD, JI_SHIELD, JI_SHIELD_UPGRADED, JI_BOMBS, JI_LAMP, JI_CLOAK,
    JI_GAUNTLET, JI_BOW, JI_HUBCAP, JI_MAP, JI_ASTROLABE, JI_RELIC,
    JI_HEART_PIECE, JI_HEART_CONTAINER, JI_KEY, JI_HEART, JI_GILT,
    JI_GILT_BIG, JI_BOMB_PICKUP, JI_ARROW1, JI_ARROW5, JI_ARROW10,
    JI_GRAIL, JI_HEALING_PETAL, JI_COUNT
};
#define JOURNAL_ENEMY_COUNT 9
#define JOURNAL_SRAM_OFFSET 0x7EC0u
#define JOURNAL_SLOT_BYTES 32u
#define JOURNAL_SRAM_END (JOURNAL_SRAM_OFFSET + 2u * JOURNAL_SLOT_BYTES)

typedef struct {
    const char* name;
    const char* description;
    u8 sheet, frame, palette;
    u8 hp, damage; /* enemy HP/contact damage; one player heart is8 HP */
} JournalEntry;

/* Read-only masks and revision support the UI and emulator evidence. */
extern u32 gJournalItems;
extern u16 gJournalEnemies;
extern u16 gJournalRevision;

void journal_init(void);
void journal_note_item(int item);
void journal_note_enemy(int type);
void journal_note_owned(void); /* seed only facts recoverable from inventory */
void journal_note_pickup(int pickup); /* PK_*: visible or collected */
void journal_note_icon(int icon); /* F_ICON32_*: awarded item */
void journal_note_shop_icon(int icon); /* F_ITEMS_*: visible stock */
bool8 journal_item_seen(int item);
bool8 journal_enemy_seen(int type);
int journal_item_count(void);
int journal_enemy_count(void);
int journal_items_found(void);
int journal_enemies_found(void);
const JournalEntry* journal_item_entry(int item);
const JournalEntry* journal_enemy_entry(int type);

#endif

extern PlayerState gPl;
/* The Drain arcade's field journal. Discovery is a profile fact: a new game,
   run death or run-save migration must not erase something Bloom has seen.
   Run SaveFile v1/v2 and appearance preferences keep their existing formats. */








#define JOURNAL_SRAM ((volatile u8*)(0x0E000000u + JOURNAL_SRAM_OFFSET))
#define JOURNAL_MAGIC 0x314E524Au /* JRN1 */
#define JOURNAL_VERSION 1u
#define ITEM_MASK (0xFFFFFFFFu >> (32 - JI_COUNT))
#define ENEMY_MASK ((1u << JOURNAL_ENEMY_COUNT) - 1u)

u32 gJournalItems;
u16 gJournalEnemies, gJournalRevision;
static u32 sGeneration;
static u8 sCurrentSlot;

typedef struct {
    u32 magic;
    u16 version, size;
    u32 generation;
    u32 items;
    u16 enemies, reserved;
    u32 reserved2[2];
    u32 sum;
} JournalRecord;
typedef char JournalRecordIs32[(sizeof(JournalRecord)==JOURNAL_SLOT_BYTES)?1:-1];
typedef char JournalBeforePreferences[(JOURNAL_SRAM_END<=APPEARANCE_SRAM_OFFSET)?1:-1];
typedef char JournalItemMaskFits[(JI_COUNT>0 && JI_COUNT<=32)?1:-1];
typedef char JournalEnemiesMatchBuild[(EN_COUNT==JOURNAL_ENEMY_COUNT)?1:-1];

#define ENTRY(n,d,s,f,p) { n,d,s,f,p,0,0 }
static const JournalEntry sItems[JI_COUNT] = {
    [JI_SWORD] = ENTRY("Sword", "A hopeful little blade. Deals 2 HP per hit. Cuts bushes and bats seeds back.", SHEET_ICON32,F_ICON32_SWORD,PAL_OBJ_IRON),
    [JI_SHIELD] = ENTRY("Bark Shield", "Hold it toward a threat. Blocks frontal bites and seeds. Your back stays exposed.", SHEET_ICON32,F_ICON32_SHIELD,PAL_OBJ_GEAR),
    [JI_SHIELD_UPGRADED] = ENTRY("Gilded Shield", "Green wood and gold trim. Uses the same frontal guard as the Bark Shield.", SHEET_ICON32,F_ICON32_SHIELD_UPGRADED,PAL_OBJ_GEAR),
    [JI_BOMBS] = ENTRY("Blightseeds", "Set one and stand clear. The blast opens cracked walls and deals 8 enemy HP.", SHEET_ICON32,F_ICON32_BOMBS,PAL_OBJ_BLIGHT),
    [JI_LAMP] = ENTRY("Grail Lamp", "Burns webs and thorns; lights censers. This flame clears terrain, not enemy HP.", SHEET_ICON32,F_ICON32_LAMP,PAL_OBJ_GEAR),
    [JI_CLOAK] = ENTRY("Petal Cloak", "Use while moving to leap a gap. Land on safe ground beyond the hole.", SHEET_ICON32,F_ICON32_CLOAK,PAL_OBJ_BUGS),
    [JI_GAUNTLET] = ENTRY("Root Gauntlet", "Worn, not equipped. Press R beside a boulder to lift it; throw it for 4 HP.", SHEET_ICON32,F_ICON32_GAUNTLET,PAL_OBJ_GEAR),
    [JI_BOW] = ENTRY("Thorn Bow", "Fires along your facing. Each arrow costs one shot and deals 2 enemy HP.", SHEET_ICON32,F_ICON32_BOW,PAL_OBJ_GEAR),
    [JI_HUBCAP] = ENTRY("Drain Cap", "Equip and use it to return to the Drain. The way home waits beneath your feet.", SHEET_ICON32,F_ICON32_HUBCAP,PAL_OBJ_IRON),
    [JI_MAP] = ENTRY("Map of the Wood", "Reveals every room's shape on the map. Discover features to learn their marks.", SHEET_ICON32,F_ICON32_MAP,PAL_OBJ_GEAR),
    [JI_ASTROLABE] = ENTRY("Astrolabe", "Adds chests, the Heart and barriers to the map. Brass remembers the hidden ways.", SHEET_ICON32,F_ICON32_ASTROLABE,PAL_OBJ_GEAR),
    [JI_RELIC] = ENTRY("The Relic", "A precious thing from another chamber. Return it to the Weeping Nun.", SHEET_ICON32,F_ICON32_RELIC,PAL_OBJ_GEAR),
    [JI_HEART_PIECE] = ENTRY("Piece of Heart", "Four quarters grow one whole heart. A little life is still worth finding.", SHEET_ICON32,F_ICON32_HEART_PIECE,PAL_OBJ_HERO),
    [JI_HEART_CONTAINER] = ENTRY("Heart Container", "Adds one heart to maximum health. One whole player heart holds 8 HP.", SHEET_ICON32,F_ICON32_HEART_CONTAINER,PAL_OBJ_HERO),
    [JI_KEY] = ENTRY("Small Key", "Walk into a locked door to spend one key. A large keyhole shows its purpose.", SHEET_ICON32,F_ICON32_KEY,PAL_OBJ_GEAR),
    [JI_HEART] = ENTRY("Heart", "A loose heart restores 8 HP: one whole player heart. Gather it by touch or sword.", SHEET_PICK32,F_PICK32_HEART,PAL_OBJ_HERO),
    [JI_GILT] = ENTRY("Gilt", "A little glimmer worth one gilt. Spend it at the frog's market in the Drain.", SHEET_PICK32,F_PICK32_GILT,PAL_OBJ_GEAR),
    [JI_GILT_BIG] = ENTRY("Purse of Gilt", "A dropped purse holds 10 gilt. Larger chest rewards may hold more. Carry up to 999.", SHEET_ICON32,F_ICON32_GILT_BIG,PAL_OBJ_GEAR),
    [JI_BOMB_PICKUP] = ENTRY("Blightseed Refill", "A dropped refill adds three seeds if you own blightseeds. Carry up to 30.", SHEET_PICK32,F_PICK32_BOMB_PICKUP,PAL_OBJ_BLIGHT),
    [JI_ARROW1] = ENTRY("Arrow", "Adds one shot for the Thorn Bow. Walls stop arrows. Carry up to 50 shots.", SHEET_PICK32,F_PICK32_ARROW1,PAL_OBJ_IRON),
    [JI_ARROW5] = ENTRY("Five Arrows", "A small tied bundle adds five shots. Ammunition never exceeds 50.", SHEET_PICK32,F_PICK32_ARROW5,PAL_OBJ_IRON),
    [JI_ARROW10] = ENTRY("Ten Arrows", "A full bundle adds ten shots. The frog sells these once you have a bow.", SHEET_PICK32,F_PICK32_ARROW10,PAL_OBJ_IRON),
    [JI_GRAIL] = ENTRY("The Grail", "The Heart releases this when it falls. Claim the Grail to finish the journey.", SHEET_PICK32,F_PICK32_GRAIL,PAL_OBJ_GEAR),
    [JI_HEALING_PETAL] = ENTRY("Healing Petal", "The frog's preserved snack costs 10 gilt and restores two player hearts.", SHEET_ITEMS,F_ITEMS_HEART,PAL_OBJ_HERO),
};
#undef ENTRY

/* Entries follow stable production enemy IDs, including the retained boss. */
static const JournalEntry sEnemies[JOURNAL_ENEMY_COUNT] = {
    [EN_BEETLE] = { "Coin Toad", "Scuttles toward nearby prey. Keep room to swing; a normal sword hit defeats it.", SHEET_BEETLE,F_BEETLE_WALK_S1,PAL_OBJ_ITEMS,2,2 },
    [EN_BAT] = { "Quill Moth", "Rests, then flies after you. Watch its body and shadow; strike when it comes close.", SHEET_BAT,F_BAT_FLY1,PAL_OBJ_ITEMS,2,2 },
    [EN_SPITTER] = { "Trumpet Bellflower", "Pauses and points before spitting. Step out of its lane or bat a seed back.", SHEET_SPITTER,F_SPITTER_IDLE_S,PAL_OBJ_BLIGHT,2,2 },
    [EN_SLIME] = { "Pear Bladder", "Compresses before a hop. Give the landing space, then close in for two sword hits.", SHEET_SLIME,F_SLIME_IDLE,PAL_OBJ_ITEMS,4,2 },
    [EN_KNIGHT] = { "Moth Confessor", "A heavy blade follows a visible windup. Dodge the strike, punish recovery. Five sword hits.", SHEET_KNIGHT,F_KNIGHT_IDLE_S,PAL_OBJ_IRON,10,4 },
    [EN_BOSS] = { "Blight Heart", "A split purple heart. Its pulse becomes spores, minions and lunges as its strength fades.", SHEET_BOSS,F_BOSS_PULSE1,PAL_OBJ_BLIGHT,40,4 },
    [EN_PROTO_ROPE] = { "Gilt Leech", "Compresses, locks a lane, then charges straight. Sidestep the rush and punish its recovery.", SHEET_PROTO_ROPE,F_PROTO_ROPE_IDLE_S,PAL_OBJ_ITEMS,4,2 },
    [EN_PROTO_LEEVER] = { "Root Maw", "A mound announces emergence. Buried and rising bodies reject hits; strike while exposed.", SHEET_PROTO_LEEVER,F_PROTO_LEEVER_IDLE_S,PAL_OBJ_BLIGHT,6,2 },
    [EN_PROTO_HELMASAUR] = { "Reliquary Snout", "Its brass front blocks hits. Dodge the committed rush and strike a soft side or rear.", SHEET_PROTO_HELMASAUR,F_PROTO_HELMASAUR_IDLE_S,PAL_OBJ_FX,4,2 },
};

static u32 journal_checksum(const JournalRecord* r) {
    const u8* data=(const u8*)r;
    u32 value=2166136261u;
    int i;
    for (i=0;i<(int)sizeof(*r)-4;i++) value=(value^data[i])*16777619u;
    return value;
}

static void read_slot(JournalRecord* r,int slot) {
    u8* data=(u8*)r;
    int i;
    for (i=0;i<(int)sizeof(*r);i++) data[i]=JOURNAL_SRAM[slot*JOURNAL_SLOT_BYTES+i];
}

static bool8 valid_slot(const JournalRecord* r) {
    return r->magic==JOURNAL_MAGIC && r->version==JOURNAL_VERSION &&
           r->size==sizeof(*r) && !(r->items&~ITEM_MASK) &&
           !(r->enemies&~ENEMY_MASK) && !r->reserved &&
           !r->reserved2[0] && !r->reserved2[1] && r->sum==journal_checksum(r);
}

static void journal_store(void) {
#if !BART_ENEMY_LAB
    JournalRecord r;
    volatile u8* target;
    const u8* data=(const u8*)&r;
    int i,slot=sCurrentSlot^1;
    r.magic=JOURNAL_MAGIC;r.version=JOURNAL_VERSION;r.size=sizeof(r);
    r.generation=sGeneration+1;r.items=gJournalItems;r.enemies=gJournalEnemies;
    r.reserved=0;r.reserved2[0]=r.reserved2[1]=0;r.sum=journal_checksum(&r);
    target=JOURNAL_SRAM+slot*JOURNAL_SLOT_BYTES;
    /* Invalidate the target first. The other complete generation stays valid.
       Publishing all four magic bytes last makes torn records reject safely. */
    for (i=0;i<4;i++) target[i]=0;
    for (i=4;i<(int)sizeof(r);i++) target[i]=data[i];
    for (i=0;i<4;i++) target[i]=data[i];
    sCurrentSlot=slot;sGeneration=r.generation;
#endif
}

void journal_init(void) {
    JournalRecord a,b;
    bool8 av,bv;
    read_slot(&a,0);read_slot(&b,1);av=valid_slot(&a);bv=valid_slot(&b);
    gJournalItems=0;gJournalEnemies=0;sGeneration=0;sCurrentSlot=1;
    if (av || bv) {
        const JournalRecord* chosen;
        if (bv && (!av || (s32)(b.generation-a.generation)>0)) {
            chosen=&b;sCurrentSlot=1;
        } else {chosen=&a;sCurrentSlot=0;}
        gJournalItems=chosen->items;gJournalEnemies=chosen->enemies;
        sGeneration=chosen->generation;
    }
    gJournalRevision++;
}

void journal_note_item(int item) {
    u32 bit;
    if (item<0 || item>=JI_COUNT) return;
    bit=1u<<item;
    if (gJournalItems&bit) return;
    gJournalItems|=bit;gJournalRevision++;journal_store();
}

void journal_note_enemy(int type) {
    u16 bit;
    if (type<0 || type>=JOURNAL_ENEMY_COUNT) return;
    bit=(u16)(1u<<type);
    if (gJournalEnemies&bit) return;
    gJournalEnemies|=bit;gJournalRevision++;journal_store();
}

void journal_note_owned(void) {
    int i;
    static const u8 bits[]={ITEM_SWORD,ITEM_SHIELD,ITEM_BOMBS,ITEM_LAMP,ITEM_CLOAK,ITEM_GAUNTLET,ITEM_RELIC};
    static const u8 ids[]={JI_SWORD,JI_SHIELD,JI_BOMBS,JI_LAMP,JI_CLOAK,JI_GAUNTLET,JI_RELIC};
    for (i=0;i<7;i++) if (gPl.items&bits[i]) journal_note_item(ids[i]);
    if (gPl.items2&ITEM2_BOW) journal_note_item(JI_BOW);
    if (gPl.items2&ITEM2_HUBCAP) journal_note_item(JI_HUBCAP);
    if (gPl.items2&ITEM2_MAP) journal_note_item(JI_MAP);
    if (gPl.items2&ITEM2_ASTROLABE) journal_note_item(JI_ASTROLABE);
    if (gPl.items2&ITEM2_SHIELD_UPGRADE) journal_note_item(JI_SHIELD_UPGRADED);
    if (gPl.keys) journal_note_item(JI_KEY);
    if (gPl.gilt) journal_note_item(JI_GILT);
    if (gPl.bombs) journal_note_item(JI_BOMBS);
    if (gPl.arrows) journal_note_item(JI_ARROW1);
    if (gPl.hearts_pieces) journal_note_item(JI_HEART_PIECE);
    /* A larger maximum may come from four quarters, so it cannot establish
       that a standalone Heart Container has ever been encountered. */
}

void journal_note_pickup(int pickup) {
    static const u8 ids[]={JI_HEART,JI_GILT,JI_BOMB_PICKUP,JI_GILT_BIG,JI_KEY,JI_RELIC,JI_GRAIL,JI_ARROW1,JI_ARROW5,JI_ARROW10};
    if (pickup>=0 && pickup<(int)(sizeof(ids)/sizeof(ids[0]))) journal_note_item(ids[pickup]);
}

void journal_note_icon(int icon) {
    static const s8 ids[]={-1,JI_BOMBS,JI_LAMP,JI_CLOAK,JI_KEY,JI_HEART_PIECE,JI_HEART_CONTAINER,
                          JI_GILT_BIG,JI_RELIC,JI_GAUNTLET,JI_BOW,JI_HUBCAP,JI_MAP,JI_ASTROLABE,
                          JI_SWORD,JI_SHIELD,JI_SHIELD_UPGRADED};
    if (icon>=0 && icon<(int)(sizeof(ids)/sizeof(ids[0])) && ids[icon]>=0) journal_note_item(ids[icon]);
}

void journal_note_shop_icon(int icon) {
    if (icon==F_ITEMS_HEART) journal_note_item(JI_HEALING_PETAL);
    else if (icon==F_ITEMS_BOMBS) journal_note_item(JI_BOMBS);
    else if (icon==F_ITEMS_ARROW10) journal_note_item(JI_ARROW10);
}

bool8 journal_item_seen(int item) {
    return item>=0 && item<JI_COUNT && (gJournalItems&(1u<<item))!=0;
}
bool8 journal_enemy_seen(int type) {
    return type>=0 && type<JOURNAL_ENEMY_COUNT && (gJournalEnemies&(1u<<type))!=0;
}
int journal_item_count(void) {return JI_COUNT;}
int journal_enemy_count(void) {return JOURNAL_ENEMY_COUNT;}
static int bit_count(u32 bits) {
    int n=0;
    while (bits) {bits&=bits-1;n++;}
    return n;
}
int journal_items_found(void) {return bit_count(gJournalItems);}
int journal_enemies_found(void) {return bit_count(gJournalEnemies);}
const JournalEntry* journal_item_entry(int item) {return item>=0 && item<JI_COUNT?&sItems[item]:0;}
const JournalEntry* journal_enemy_entry(int type) {return type>=0 && type<JOURNAL_ENEMY_COUNT?&sEnemies[type]:0;}

PlayerState gPl;
static int checks, guard_checks;
#define CHECK(test) do {checks++;if (!(test)) {fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#test);exit(1);}} while(0)
#define GUARD(test) do {guard_checks++;if (!(test)) {fprintf(stderr,"FAIL protected byte line%d\n",__LINE__);exit(1);}} while(0)
static unsigned char snapshot[32768];
static unsigned char* ram;
static void fresh(void) {memset(ram,0xA7,32768);memset(&gPl,0,sizeof(gPl));journal_init();}
static void unchanged_outer(void) {
    int i;
    for(i=0;i<JOURNAL_SRAM_OFFSET;i++)GUARD(ram[i]==0xA7);
    for(i=JOURNAL_SRAM_END;i<32768;i++)GUARD(ram[i]==0xA7);
}
int main(void) {
    int i;
    JournalRecord rec;
    ram=mmap((void*)0x0E000000u,32768,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);
    CHECK(ram!=(void*)-1);fresh();CHECK(!gJournalItems&&!gJournalEnemies);
    CHECK(journal_item_count()==24&&journal_enemy_count()==9);
#if BART_ENEMY_LAB
    memcpy(snapshot,ram,32768);
    for(i=0;i<24;i++)journal_note_item(i);
    for(i=0;i<9;i++)journal_note_enemy(i);
    CHECK(gJournalItems==0xFFFFFFu&&gJournalEnemies==0x1FF);
    CHECK(journal_items_found()==24&&journal_enemies_found()==9);
    CHECK(memcmp(snapshot,ram,32768)==0);
    /* Profile knowledge may load in the lab; new fixture discoveries stay RAM-only. */
    memset(&rec,0,sizeof(rec));rec.magic=JOURNAL_MAGIC;rec.version=JOURNAL_VERSION;rec.size=sizeof(rec);
    rec.items=1u<<JI_SWORD;rec.enemies=1u<<EN_BOSS;rec.sum=journal_checksum(&rec);
    memcpy(ram+JOURNAL_SRAM_OFFSET,&rec,sizeof(rec));memcpy(snapshot,ram,32768);
    journal_init();CHECK(journal_item_seen(JI_SWORD)&&journal_enemy_seen(EN_BOSS));
    journal_note_item(JI_SHIELD);journal_note_enemy(EN_GILT_LEECH);
    CHECK(journal_items_found()==2&&journal_enemies_found()==2);
    CHECK(memcmp(snapshot,ram,32768)==0);
#else
    memcpy(snapshot,ram,32768);journal_note_item(-1);journal_note_item(24);journal_note_enemy(-1);journal_note_enemy(9);
    CHECK(memcmp(snapshot,ram,32768)==0);
    journal_note_item(JI_SWORD);CHECK(journal_item_seen(JI_SWORD));CHECK(journal_items_found()==1);CHECK(sGeneration==1);
    memcpy(snapshot,ram,32768);journal_note_item(JI_SWORD);CHECK(memcmp(snapshot,ram,32768)==0);CHECK(sGeneration==1);
    journal_note_enemy(EN_BOSS);CHECK(journal_enemy_seen(EN_BOSS));CHECK(journal_enemies_found()==1);
    gJournalItems=gJournalEnemies=0;journal_init();CHECK(journal_item_seen(JI_SWORD)&&journal_enemy_seen(EN_BOSS));
    journal_note_item(JI_BOW);CHECK(journal_item_seen(JI_BOW));
    /* Latest checksum corruption falls back to the other complete generation. */
    ram[JOURNAL_SRAM_OFFSET+sCurrentSlot*JOURNAL_SLOT_BYTES+31]^=0x80;
    journal_init();CHECK(journal_item_seen(JI_SWORD)&&journal_enemy_seen(EN_BOSS));CHECK(!journal_item_seen(JI_BOW));
    /* A partially published target cannot replace a valid old generation. */
    read_slot(&rec,sCurrentSlot);rec.generation++;rec.items|=1u<<JI_CLOAK;rec.sum=journal_checksum(&rec);
    memcpy(ram+JOURNAL_SRAM_OFFSET+(sCurrentSlot^1)*JOURNAL_SLOT_BYTES,&rec,sizeof(rec));
    ram[JOURNAL_SRAM_OFFSET+(sCurrentSlot^1)*JOURNAL_SLOT_BYTES]=0;
    journal_init();CHECK(journal_item_seen(JI_SWORD)&&!journal_item_seen(JI_CLOAK));
    ram[JOURNAL_SRAM_OFFSET]=ram[JOURNAL_SRAM_OFFSET+JOURNAL_SLOT_BYTES]=0;
    memcpy(snapshot,ram,32768);journal_init();CHECK(!gJournalItems&&!gJournalEnemies);CHECK(memcmp(snapshot,ram,32768)==0);
    for(i=0;i<24;i++)journal_note_item(i);
    for(i=0;i<9;i++)journal_note_enemy(i);
    CHECK(gJournalItems==0xFFFFFFu&&gJournalEnemies==0x1FF);CHECK(journal_items_found()==24&&journal_enemies_found()==9);
    for(i=0;i<24;i++) {const JournalEntry* e=journal_item_entry(i);CHECK(e&&e->name[0]&&e->description[0]);CHECK(journal_item_seen(i));CHECK(strlen(e->description)<=160);}
    for(i=0;i<9;i++) {const JournalEntry* e=journal_enemy_entry(i);CHECK(e&&e->name[0]&&e->description[0]);CHECK(journal_enemy_seen(i));CHECK(e->hp&&e->damage);}
    CHECK(journal_item_entry(-1)==NULL&&journal_item_entry(24)==NULL&&journal_enemy_entry(-1)==NULL&&journal_enemy_entry(9)==NULL);
    CHECK(!journal_item_seen(-1)&&!journal_item_seen(24)&&!journal_enemy_seen(-1)&&!journal_enemy_seen(9));
    unchanged_outer();
    fresh();gPl.items=0x7F;gPl.items2=0x1F;gPl.keys=1;gPl.gilt=12;gPl.bombs=30;gPl.arrows=50;gPl.hearts_pieces=2;journal_note_owned();
    CHECK(journal_items_found()==16);CHECK(!journal_item_seen(JI_HEART_CONTAINER));CHECK(!journal_item_seen(JI_ARROW5)&&!journal_item_seen(JI_ARROW10));CHECK(!journal_item_seen(JI_BOMB_PICKUP)&&!journal_item_seen(JI_HEALING_PETAL));
    fresh();for(i=0;i<10;i++)journal_note_pickup(i);CHECK(journal_items_found()==10);CHECK(journal_item_seen(JI_BOMB_PICKUP)&&journal_item_seen(JI_GRAIL));
    fresh();for(i=0;i<17;i++)journal_note_icon(i);CHECK(journal_items_found()==16);CHECK(!journal_item_seen(JI_HEART)&&!journal_item_seen(JI_GILT));
    fresh();journal_note_shop_icon(F_ITEMS_HEART);journal_note_shop_icon(F_ITEMS_BOMBS);journal_note_shop_icon(F_ITEMS_ARROW10);CHECK(journal_items_found()==3);CHECK(journal_item_seen(JI_HEALING_PETAL)&&journal_item_seen(JI_ARROW10));
    unchanged_outer();
    fresh();memset(&rec,0,sizeof(rec));rec.magic=JOURNAL_MAGIC;rec.version=JOURNAL_VERSION;rec.size=sizeof(rec);rec.generation=0xFFFFFFFFu;rec.items=1u<<JI_SWORD;rec.sum=journal_checksum(&rec);memcpy(ram+JOURNAL_SRAM_OFFSET,&rec,sizeof(rec));
    rec.generation=0;rec.items|=1u<<JI_SHIELD;rec.sum=journal_checksum(&rec);memcpy(ram+JOURNAL_SRAM_OFFSET+JOURNAL_SLOT_BYTES,&rec,sizeof(rec));journal_init();CHECK(journal_items_found()==2&&sCurrentSlot==1&&sGeneration==0);
#endif
    printf("{\"functional_checks\":%d,\"protected_byte_checks\":%d}\n",checks,guard_checks);
    return 0;
}
