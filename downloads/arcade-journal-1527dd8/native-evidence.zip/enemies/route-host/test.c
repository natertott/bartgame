#include <stdio.h>
#include <stdint.h>
typedef int bool8;
#define TRUE 1
#define FALSE 0
#define PX(v) ((v)>>16)
#define ABS(v) ((v)<0?-(v):(v))
#define MAX(a,b) ((a)>(b)?(a):(b))
typedef struct {int x,y;} Actor;
static Actor player={100<<16,200<<16};
static Actor* gPlayer=&player;
static int px[512],py[512],count;
static bool8 dry_footprint(int x,int y) {px[count]=x;py[count]=y;count++;return TRUE;}
static bool8 reachable_dry(int x,int y) {
    int i,ox=PX(gPlayer->x),oy=PX(gPlayer->y),dx=x-ox,dy=y-oy;
    int steps=(MAX(ABS(dx),ABS(dy))+3)/4;
    int qx,qy,rx,ry,ex=0,ey=0,sx=dx<0?-1:1,sy=dy<0?-1:1;
    if (!dry_footprint(ox,oy)) return FALSE;
    if (!steps) return TRUE;
    /* Exact rational DDA: these are the same C-truncated coordinates as
       ox+dx*i/steps,oy+dy*i/steps, without two divisions at every sample.
       Signed quotients and positive residual carries preserve negative rays. */
    qx=dx/steps;qy=dy/steps;
    rx=ABS(dx)-ABS(qx)*steps;ry=ABS(dy)-ABS(qy)*steps;
    for (i=1;i<=steps;i++) {
        ox+=qx;oy+=qy;ex+=rx;ey+=ry;
        if(ex>=steps) {ox+=sx;ex-=steps;}
        if(ey>=steps) {oy+=sy;ey-=steps;}
        if (!dry_footprint(ox,oy)) return FALSE;
    }
    return TRUE;
}

int main(void) {
    int dx,dy,i;long long vectors=0,samples=0;
    for(dx=-512;dx<=512;dx++) for(dy=-512;dy<=512;dy++) {
        int n=(MAX(ABS(dx),ABS(dy))+3)/4;
        count=0;
        if(!reachable_dry(100+dx,200+dy) || count!=n+1) return 1;
        if(px[0]!=100 || py[0]!=200) return 2;
        for(i=1;i<=n;i++) if(px[i]!=100+dx*i/n || py[i]!=200+dy*i/n) {
            fprintf(stderr,"mismatch dx%d dy%d sample%d\n",dx,dy,i);return 3;
        }
        vectors++;samples+=count;
    }
    printf("%lld %lld\n",vectors,samples);return 0;
}
