BARTGAME original standalone GBA game.
Source: 2bc08ecad81e0acbf52933cf6d69c3ad2e2414ce
ROM SHA256: e8df68ad63350948894742cad7e4f4085600857f26ec55aaa545b0697cd9954e
See the adjacent README.md and curdled-cream-review/README.md for controls, the feature audit and actual mGBA captures.
