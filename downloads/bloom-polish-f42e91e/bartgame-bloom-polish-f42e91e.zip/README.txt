BARTGAME — Bloom animation polish

Source commit: f42e91e60c026416d78d7bd9ce86e9f8c9aad673
Branch: forest-art

Open bartgame.gba in mGBA. This is the final tested ROM from the Bloom
animation update. The source and actual mGBA comparison clips are at:
https://github.com/natertott/bartgame/tree/forest-art/forest-review/bloom-animation

Validation: 1,812 animation, gameplay and sprite-memory checks passed.
ROM SHA256: b8d76c00875361f14c308fcf591f12903870c063ddd749780d29dca5142ef7d5
