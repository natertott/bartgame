BARTGAME — imported title reference

Source commit: 66422bcfafdbbaf24ea2018a4882c5871b3d5866
Branch: forest-art
ROM SHA256: 629b27d29cbffbfee63a8b70c450cdbd95a28da5bae78a43aa4401d081d7a211

Open bartgame.gba in mGBA.

The opening screen imports the supplied title screenshot at240x160 inRGB555.
Title79/79, menu21/21 and Bloom animation274/274 checks passed in mGBA.

https://github.com/natertott/bartgame/tree/forest-art/forest-review/title-reference
