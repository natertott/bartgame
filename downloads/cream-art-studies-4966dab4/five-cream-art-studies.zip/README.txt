Five optional Curdled Cream native art studies.
Source 4966dab4132218b9d2692fbb62165a22c70f52c3
Default production art remains unchanged.
See cream-art-review/README.md on the cream-art-studies branch for comparisons, controls and real mGBA footage.
