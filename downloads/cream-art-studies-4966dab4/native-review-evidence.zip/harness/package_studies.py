import json,hashlib,shutil,os,subprocess,zipfile
from pathlib import Path
repo=Path('/workspace/bartgame');root=Path('/workspace/setup/cream-studies');review=repo/'cream-art-review';downloads=repo/'downloads/cream-art-studies-4966dab4'
source=(root/'frozen/style-1-r2/source-commit.txt').read_text().strip()
assert source=='4966dab4132218b9d2692fbb62165a22c70f52c3'
styles=[('original','Original Cream'),('curdstone-karst','Curdstone Karst'),('brine-basilica','Brine Basilica'),('moldglass-crags','Moldglass Crags'),('gilt-quarry','Gilt Quarry'),('black-rind-terraces','Black Rind Terraces')]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def copy_public(folder,destination):
 for p in folder.rglob('*'):
  rel=p.relative_to(folder)
  if not p.is_file() or any(part.startswith('private') for part in rel.parts):continue
  if p.suffix.lower() not in ('.png','.gif','.json','.md','.txt','.py'):continue
  out=destination/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
manifest={'source_commit':source,'normal_production_unchanged':True,'variants':[],'gallery':[]}
for n,(slug,name) in enumerate(styles):
 bundle=root/f'frozen/style-{n}-r2';captures=root/f'native-r2/style-{n}'
 report=json.loads((captures/'report.json').read_text());assert report['source_commit']==source
 assert report['rom_sha256']==sha(bundle/'bartgame.gba')
 checks=[check for case in report['cases'] for check in case['checks']]
 assert report['complete'] and len(checks)==61 and all(c['passed'] for c in checks)
 copy_public(captures,review/'validation'/f'style-{n}')
 entry=dict(number=n,name=name,slug=slug,rom_sha256=sha(bundle/'bartgame.gba'),source_commit=source,report=f'validation/style-{n}/report.json')
 if n:
  filename=f'{n:02d}-{slug}-4966dab4.gba';shutil.copy2(bundle/'bartgame.gba',downloads/filename);entry['rom']=filename
  subprocess.run(['python','-c','import cream_terrain,sys;cream_terrain.write_review(sys.argv[1])',str(review/'source'/slug)],cwd=repo/'bartgame/art',env=dict(os.environ,BART_CREAM=str(n)),check=True)
 for case in ('healthy','sour','deep'):
  for filename,kind in [('registered-renderer/full-room.png','registered512x384 mosaic of9 actual native camera frames; frozen renderer, HUD hidden'),('ordinary-live/start.png','ordinary live240x160 mGBA frame'),('ordinary-live/climbing.png','ordinary live240x160 mGBA frame'),('ordinary-live/landed.png','ordinary live240x160 mGBA frame'),('ordinary-live/climb.gif','actual real-input mGBA climb recording')]:
   src=captures/case/filename
   if not src.exists():
    if filename.endswith('start.png'):src=captures/case/'ordinary-live/before.png'
    if filename.endswith('climb.gif'):src=captures/case/'ordinary-live/climbing.gif'
   if not src.exists():continue
   suffix=src.suffix;tag='room' if filename.startswith('registered') else src.stem
   dest=review/'images'/f'{n:02d}-{slug}-{case}-{tag}{suffix}';shutil.copy2(src,dest)
   manifest['gallery'].append(dict(file=str(dest.relative_to(review)),source=str(src),sha256=sha(src),kind=kind,rom_sha256=entry['rom_sha256'],style=n))
 manifest['variants'].append(entry)
shutil.copy2(root/'native-r2/comparison.json',review/'validation/comparison.json')
shutil.copy2(root/'audit/native-audit.json',review/'validation/native-audit.json')
shutil.copy2(root/'audit/final-semantic-checks.json',review/'validation/semantic-checks.json')
shutil.copy2(root/'CAPTURE_NOTES.md',review/'validation/CAPTURE_NOTES.md')
shutil.copy2(root/'audit/INDEPENDENT_SOURCE_REVIEW.md',review/'validation/INDEPENDENT_SOURCE_REVIEW.md')
(review/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(downloads/'build-manifest.json').write_text(json.dumps({k:v for k,v in manifest.items() if k!='gallery'},indent=2)+'\n')
with zipfile.ZipFile(downloads/'five-cream-art-studies.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for entry in manifest['variants'][1:]:z.write(downloads/entry['rom'],entry['rom'])
 z.writestr('README.txt','Five optional Curdled Cream native art studies.\nSource '+source+'\nDefault production art remains unchanged.\nSee cream-art-review/README.md on the cream-art-studies branch for comparisons, controls and real mGBA footage.\n')
 z.writestr('build-manifest.json',(downloads/'build-manifest.json').read_bytes())
with zipfile.ZipFile(downloads/'native-review-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in review.rglob('*'):
  if p.is_file():z.write(p,'review/'+str(p.relative_to(review)))
 for n in range(6):
  for filename in ('assets.h','bartgame.map','source-commit.txt','build-options.json'):
   z.write(root/f'frozen/style-{n}-r2'/filename,f'frozen/style-{n}/'+filename)
 for filename in ('cream_art_study_capture.py','cream_art_study_audit.py'):
  z.write(repo/'bartgame/tools'/filename,'harness/'+filename)
 z.write(Path(__file__),'harness/package_studies.py')
print('variants',len(manifest['variants'])-1,'gallery files',len(manifest['gallery']))
print('review',sum(p.stat().st_size for p in review.rglob('*') if p.is_file()))
for p in downloads.iterdir():print(p.name,p.stat().st_size)
