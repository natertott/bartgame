BARTGAME — supplied item and shield artwork

Source commit: ac29db738895d4f27bd6360b4af745db5f6f27f2
Branch: forest-art
ROM SHA256: 22655879ab59d8c93a80e7dfcbaecec98465bb5f723086233c25516e0efd3d45

Open bartgame.gba in mGBA.

Includes the imported title screenshot, supplied item and shield art,
material palettes, exact inventory palettes, and the Bloom animation polish.
Wooden shield starts owned. Green-and-gold shield is wired as an upgrade
variant; it has not been assigned to a new loot reward.

All 2920 rendering, palette, gameplay and title checks passed.

https://github.com/natertott/bartgame/tree/forest-art/forest-review/items-reference
