BARTGAME original standalone GBA game.
Source: 0b9344d781e65e304d245bd9ae4aecdbc7056837
ROM SHA256: b348cf4d628aee1abb9b71d8885a9f04094332c5252490ff2dd8f8e7cd0bf1b8
See the adjacent README.md and curdled-cream-review/README.md for controls, the feature audit and actual mGBA captures.
